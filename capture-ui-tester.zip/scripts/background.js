console.log("Background service worker loaded.");
